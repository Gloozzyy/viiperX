﻿using System.Reflection;

[assembly: Obfuscation(Feature = "type renaming pattern 'VIIAD'.*", Exclude = false)]
[assembly: Obfuscation(Feature = "encrypt symbol names with password vubhIUfr6t3u90N6eNAEvM3NO5A6unxW", Exclude = false)]
[assembly: Obfuscation(Feature = "string encryption", Exclude = true)]