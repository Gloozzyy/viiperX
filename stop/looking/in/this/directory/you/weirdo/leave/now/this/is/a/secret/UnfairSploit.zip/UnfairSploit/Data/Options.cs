﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnfairSploit.Data
{
    public class Options
    {
        [JsonProperty("unlockFPS")]
        public bool UnlockFPS { get; set; }
    }
}
