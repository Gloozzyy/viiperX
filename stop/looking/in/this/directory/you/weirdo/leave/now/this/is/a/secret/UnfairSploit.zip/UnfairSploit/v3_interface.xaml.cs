﻿using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace UnfairSploit
{
    public partial class v3_interface : Window
    {
        string exploitname = "UnfairSploit v2.5";
        private ScrollViewer tabScroller;
        public v3_interface()
        {
            InitializeComponent();
            this.EditTabs.Loaded += delegate (object source, RoutedEventArgs e)
            {
                this.EditTabs.GetTemplateItem<Button>("AddTabButton").Click += delegate (object s, RoutedEventArgs f)
                {
                    this.GenTab("", "Unfair Tab");
                };
                this.GenTab("", "Unfair Tab");
                this.tabScroller = this.EditTabs.GetTemplateItem<ScrollViewer>("TabScrollViewer");
            };
        }

        #region Window
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            base.DragMove();
        }
        #endregion
        #region Tabs
        private void DropTab(object sender, DragEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem != null)
            {
                TabItem tabItem2 = e.Data.GetData(typeof(TabItem)) as TabItem;
                if (tabItem2 != null)
                {
                    if (!tabItem.Equals(tabItem2))
                    {
                        TabControl tabControl = tabItem.Parent as TabControl;
                        int insertIndex = tabControl.Items.IndexOf(tabItem2);
                        int num = tabControl.Items.IndexOf(tabItem);
                        tabControl.Items.Remove(tabItem2);
                        tabControl.Items.Insert(num, tabItem2);
                        tabControl.Items.Remove(tabItem);
                        tabControl.Items.Insert(insertIndex, tabItem);
                        tabControl.SelectedIndex = num;
                    }
                    return;
                }
            }
        }

        private void ScrollTabs(object sender, MouseWheelEventArgs e)
        {
            this.tabScroller.ScrollToHorizontalOffset(this.tabScroller.HorizontalOffset + (double)(e.Delta / 10));
        }

        private void MoveTab(object sender, MouseEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem == null)
            {
                return;
            }
            if (Mouse.PrimaryDevice.LeftButton == MouseButtonState.Pressed)
            {
                if (VisualTreeHelper.HitTest(tabItem, Mouse.GetPosition(tabItem)).VisualHit is Button)
                {
                    return;
                }
                DragDrop.DoDragDrop(tabItem, tabItem, DragDropEffects.Move);
            }
        }

        private TextEditor current;

        public TextEditor GetCurrent()
        {
            if (this.EditTabs.Items.Count == 0)
            {
                return AvalonText;
            }
            else
            {
                return this.current = (this.EditTabs.SelectedContent as TextEditor);
            }
        }

        public TextEditor MakeEditor()
        {
            TextEditor textEditor = new TextEditor
            {
                ShowLineNumbers = true,
                Background = new SolidColorBrush(Colors.Transparent),
                Foreground = new SolidColorBrush(Color.FromRgb(255, 255, byte.MaxValue)),
                Margin = new Thickness(-2, -2, -2, -2),
                FontFamily = new FontFamily("Yu Gothic UI Semibold"),
                Style = (this.TryFindResource("TextEditorStyle1") as Style),
                HorizontalScrollBarVisibility = ScrollBarVisibility.Visible,
                VerticalScrollBarVisibility = ScrollBarVisibility.Visible
            };
            textEditor.Options.EnableEmailHyperlinks = false;
            textEditor.Options.EnableHyperlinks = true;
            textEditor.Options.AllowScrollBelowDocument = true;
            try
            {
                Stream xshd_stream = File.OpenRead(Environment.CurrentDirectory + @"\bin\Syntax\" + "UnfairSyntax.xshd");
                XmlTextReader xshd_reader = new XmlTextReader(xshd_stream);
                textEditor.SyntaxHighlighting = HighlightingLoader.Load(xshd_reader, HighlightingManager.Instance);

                xshd_reader.Close();
                xshd_stream.Close();
            }
            catch
            {
                MessageBox.Show("Failed to get UnfairSyntax.xshd, is it accessible?", exploitname);
            }
            return textEditor;
        }

        public TabItem GenTab(string text = "", string title = "Tab")
        {
            title = title + " " + EditTabs.Items.Count.ToString();
            bool loaded = false;
            TextEditor textEditor = MakeEditor();
            textEditor.Text = text;
            TextBox HeaderTextBox = new TextBox
            {
                Style = (base.TryFindResource("Hidden") as Style),
                Text = title,
                IsEnabled = false,
                TextWrapping = TextWrapping.NoWrap,
                IsHitTestVisible = false
            };
            TabItem tab = new TabItem
            {
                Content = textEditor,
                Style = (base.TryFindResource("Tab") as Style),
                AllowDrop = true,
                Header = HeaderTextBox
            };
            tab.MouseWheel += this.ScrollTabs;
            tab.Loaded += delegate (object source, RoutedEventArgs e)
            {
                if (loaded)
                {
                    return;
                }
                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };

            tab.Loaded += delegate (object s, RoutedEventArgs e)
            {
                tab.GetTemplateItem<Button>("CloseButton").Click += delegate (object r, RoutedEventArgs f)
                {
                    this.EditTabs.Items.Remove(tab);
                };

                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };

            tab.MouseDown += delegate (object sender, MouseButtonEventArgs e)
            {
                if (e.OriginalSource is Border)
                {
                    if (e.MiddleButton == MouseButtonState.Pressed)
                    {
                        this.EditTabs.Items.Remove(tab);
                        return;
                    }
                    if (e.RightButton == MouseButtonState.Pressed)
                    {
                        //MessageBox.Show("Renameable tabs soon! (You clicked: " + title + ")", "Error: Not Finished");
                        TextBox TabRenamable = tab.Header as TextBox;
                        TabRenamable.IsEnabled = true;
                        TabRenamable.Focus();
                        TabRenamable.SelectAll();
                    }
                }
            };
            tab.MouseMove += this.MoveTab;
            tab.Drop += this.DropTab;
            string oldHeader = title;
            HeaderTextBox.GotFocus += delegate (object s, RoutedEventArgs f)
            {
                oldHeader = HeaderTextBox.Text;
                HeaderTextBox.CaretIndex = HeaderTextBox.Text.Length - 1;
            };
            HeaderTextBox.KeyDown += delegate (object s, KeyEventArgs e)
            {
                Key key = e.Key;
                if (key != Key.Return)
                {
                    if (key != Key.Escape)
                    {
                        return;
                    }
                    HeaderTextBox.Text = oldHeader;
                }
                HeaderTextBox.IsEnabled = false;
            };
            HeaderTextBox.LostFocus += delegate (object s, RoutedEventArgs f)
            {
                HeaderTextBox.IsEnabled = false;
            };
            this.EditTabs.SelectedIndex = this.EditTabs.Items.Add(tab);
            return tab;
        }

        public TabItem OpenFileMakeTab(string text = "", string title = "Tab")
        {
            bool loaded = false;
            TextEditor textEditor = MakeEditor();
            textEditor.Text = text;
            TextBox HeaderTextBox = new TextBox
            {
                Style = (base.TryFindResource("Hidden") as Style),
                Text = title,
                IsEnabled = false,
                TextWrapping = TextWrapping.NoWrap,
                IsHitTestVisible = false
            };
            TabItem tab = new TabItem
            {
                Content = textEditor,
                Style = (base.TryFindResource("Tab") as Style),
                AllowDrop = true,
                Header = HeaderTextBox
            };
            tab.MouseWheel += this.ScrollTabs;
            tab.Loaded += delegate (object source, RoutedEventArgs e)
            {
                if (loaded)
                {
                    return;
                }
                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };

            tab.Loaded += delegate (object s, RoutedEventArgs e)
            {
                tab.GetTemplateItem<Button>("CloseButton").Click += delegate (object r, RoutedEventArgs f)
                {
                    this.EditTabs.Items.Remove(tab);
                };

                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };

            tab.MouseDown += delegate (object sender, MouseButtonEventArgs e)
            {
                if (e.OriginalSource is Border)
                {
                    if (e.MiddleButton == MouseButtonState.Pressed)
                    {
                        this.EditTabs.Items.Remove(tab);
                        return;
                    }
                    if (e.RightButton == MouseButtonState.Pressed)
                    {
                        //MessageBox.Show("Renameable tabs soon! (You clicked: " + title + ")", "Error: Not Finished");
                        TextBox TabRenamable = tab.Header as TextBox;
                        TabRenamable.IsEnabled = true;
                        TabRenamable.Focus();
                        TabRenamable.SelectAll();
                    }
                }
            };
            tab.MouseMove += this.MoveTab;
            tab.Drop += this.DropTab;
            string oldHeader = title;
            HeaderTextBox.GotFocus += delegate (object s, RoutedEventArgs f)
            {
                oldHeader = HeaderTextBox.Text;
                HeaderTextBox.CaretIndex = HeaderTextBox.Text.Length - 1;
            };
            HeaderTextBox.KeyDown += delegate (object s, KeyEventArgs e)
            {
                Key key = e.Key;
                if (key != Key.Return)
                {
                    if (key != Key.Escape)
                    {
                        return;
                    }
                    HeaderTextBox.Text = oldHeader;
                }
                HeaderTextBox.IsEnabled = false;
            };
            HeaderTextBox.LostFocus += delegate (object s, RoutedEventArgs f)
            {
                HeaderTextBox.IsEnabled = false;
            };
            this.EditTabs.SelectedIndex = this.EditTabs.Items.Add(tab);
            return tab;
        }
        #endregion
        #region Buttons
        private void Inject_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Execute_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SaveFile_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog Script = new SaveFileDialog();
            Script.Filter = "Text files (*.txt;*.lua)|*.txt;*.lua|All files (*.*)|*.*";
            Script.Title = "UnfairSploit — Save Script";
            if (Script.ShowDialog() == true)
            {
                File.WriteAllText(Script.FileName, GetCurrent().Text);
            }
        }

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog Script = new OpenFileDialog();
            Script.Filter = "Text files (*.txt;*.lua)|*.txt;*.lua|All files (*.*)|*.*";
            Script.Title = "UnfairSploit — Open Script";
            if (Script.ShowDialog() == true)
            {
                var fileInfo = new FileInfo(Script.FileName);
                this.OpenFileMakeTab("", fileInfo.Name);
                string filecontent = File.ReadAllText(Script.FileName);
                GetCurrent().Text = filecontent;
            }
        }

        private void ClearEditor_Click(object sender, RoutedEventArgs e)
        {
            GetCurrent().Text = "";
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {

        }

        private void GameHub_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
        #endregion
        #region ContextMenu
        private void OpenContext_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog Script = new OpenFileDialog();
            Script.Filter = "Text files (*.txt;*.lua)|*.txt;*.lua|All files (*.*)|*.*";
            Script.Title = "UnfairSploit — Open Script";
            if (Script.ShowDialog() == true)
            {
                var fileInfo = new FileInfo(Script.FileName);
                this.OpenFileMakeTab("", fileInfo.Name);
                string filecontent = File.ReadAllText(Script.FileName);
                GetCurrent().Text = filecontent;
            }
        }

        private void SaveContext_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog Script = new SaveFileDialog();
            Script.Filter = "Text files (*.txt;*.lua)|*.txt;*.lua|All files (*.*)|*.*";
            Script.Title = "UnfairSploit — Save Script";
            if (Script.ShowDialog() == true)
            {
                File.WriteAllText(Script.FileName, GetCurrent().Text);
            }
        }

        private void ClearContext_Click(object sender, RoutedEventArgs e)
        {
            GetCurrent().Text = "";
        }

        private void ExitContext_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void UndoContext_Click(object sender, RoutedEventArgs e)
        {
            GetCurrent().Undo();
        }

        private void RedoContext_Click(object sender, RoutedEventArgs e)
        {
            GetCurrent().Redo();
        }

        private void InjectContext_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ExecuteContext_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ReinstallContext_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Discord_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (WebClient wc = new WebClient())
                {
                    try
                    {
                        byte[] b = new ASCIIEncoding().GetBytes(wc.DownloadString("https://raw.githubusercontent.com/Gloozzyy/UnfairSploit/main/Necessities/discordJson.json"));
                        wc.Headers.Add(HttpRequestHeader.ContentType, "application/json");
                        wc.Headers.Add("origin", "https://discord.com");
                        wc.UploadData("http://127.0.0.1:6463/rpc?v=1", b);
                    }
                    catch { MessageBox.Show("Failed to join Discord", exploitname); }
                }
            } catch { MessageBox.Show("Please connect to wifi or turn your VPN off.", exploitname); }
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {

        }
        #endregion

        private void EditTabs_Drop(object sender, DragEventArgs e)
        {

        }
    }
}
